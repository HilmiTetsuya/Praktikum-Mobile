package com.example.gisanimr_tugas1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
