import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'top_album.dart';



void main(){
  runApp(myApp());
}

class myApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kuis Mobile',
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Spoti-fot'),
      ),

          body: ListView.builder(
    itemBuilder: (context, index) {
    final TopAlbum album = topAlbumList[index];
    return InkWell(
    onTap: () {

    },
      child: Card(
      child: Row(
      children: [
      Image.network(album.imageUrls,width: 64,),
      Text(album.albumName),
      Text(album.singer)
      ],
      ),
      ),
      );
      },
        itemCount: topAlbumList.length,),
    );
  }
}